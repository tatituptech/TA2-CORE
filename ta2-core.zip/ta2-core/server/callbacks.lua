TA2Core.ServerCallbacks = {}

-- Register Callback
TA2Core.Functions.CreateCallback = function(name, cb)
    TA2Core.ServerCallbacks[name] = cb
end

-- Trigger Callback
RegisterNetEvent('TA2Core:Server:TriggerCallback', function(name, ...)
    local src = source
    
    if not TA2Core.ServerCallbacks[name] then
        print('^1[TA2-Core]^7 Callback ' .. name .. ' does not exist!')
        return
    end
    
    TA2Core.ServerCallbacks[name](src, function(...)
        TriggerClientEvent('TA2Core:Client:TriggerCallback', src, name, ...)
    end, ...)
end)

-- Example Callbacks
TA2Core.Functions.CreateCallback('TA2Core:GetPlayerData', function(source, cb)
    local Player = TA2Core.Functions.GetPlayer(source)
    cb(Player.PlayerData)
end)

TA2Core.Functions.CreateCallback('TA2Core:GetPlayers', function(source, cb)
    local players = {}
    for k, v in pairs(TA2Core.Players) do
        players[#players + 1] = TA2Core.Players[k].PlayerData
    end
    cb(players)
end)

TA2Core.Functions.CreateCallback('TA2Core:Server:GetObject', function(source, cb)
    cb(TA2Core)
end)
