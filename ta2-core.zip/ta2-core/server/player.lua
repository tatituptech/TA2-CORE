-- Player Object Creation
TA2Core.Functions.CreatePlayer = function(source, citizenid)
    local license = TA2Core.Functions.GetIdentifier(source, 'license')
    local PlayerData = {}
    
    if citizenid then
        -- Load existing player
        local result = MySQL.query.await('SELECT * FROM players WHERE citizenid = ? LIMIT 1', {citizenid})
        if result[1] then
            PlayerData = result[1]
            PlayerData.money = json.decode(PlayerData.money)
            PlayerData.job = json.decode(PlayerData.job)
            PlayerData.position = json.decode(PlayerData.position)
            PlayerData.metadata = json.decode(PlayerData.metadata)
            PlayerData.charinfo = json.decode(PlayerData.charinfo)
            PlayerData.gang = json.decode(PlayerData.gang or '{}')
        end
    else
        -- Check if player exists with this license
        local result = MySQL.query.await('SELECT * FROM players WHERE license = ? LIMIT 1', {license})
        if result[1] then
            PlayerData = result[1]
            PlayerData.money = json.decode(PlayerData.money)
            PlayerData.job = json.decode(PlayerData.job)
            PlayerData.position = json.decode(PlayerData.position)
            PlayerData.metadata = json.decode(PlayerData.metadata)
            PlayerData.charinfo = json.decode(PlayerData.charinfo)
            PlayerData.gang = json.decode(PlayerData.gang or '{}')
        else
            -- Create new player
            PlayerData.citizenid = TA2Core.Functions.CreateCitizenId()
            PlayerData.license = license
            PlayerData.name = GetPlayerName(source)
            PlayerData.money = {
                cash = Config.StartingCash,
                bank = Config.StartingBank
            }
            PlayerData.charinfo = {
                firstname = 'John',
                lastname = 'Doe',
                birthdate = '01/01/2000',
                gender = 0,
                nationality = 'USA',
                phone = TA2Core.Shared.RandomInt(8)
            }
            PlayerData.job = {
                name = Config.DefaultJob,
                label = TA2Core.Shared.Jobs[Config.DefaultJob].label,
                payment = TA2Core.Shared.Jobs[Config.DefaultJob].grades[tostring(Config.DefaultGrade)].payment,
                onduty = true,
                isboss = false,
                grade = {
                    name = TA2Core.Shared.Jobs[Config.DefaultJob].grades[tostring(Config.DefaultGrade)].name,
                    level = Config.DefaultGrade
                }
            }
            PlayerData.gang = {
                name = 'none',
                label = 'No Gang',
                isboss = false,
                grade = {
                    name = 'none',
                    level = 0
                }
            }
            PlayerData.position = Config.DefaultSpawn
            PlayerData.metadata = {
                hunger = 100,
                thirst = 100,
                stress = 0,
                isdead = false,
                inlaststand = false,
                armor = 0,
                ishandcuffed = false,
                tracker = false,
                injail = 0,
                jailitems = {},
                status = {},
                phone = {},
                fitbit = {},
                commandbinds = {},
                bloodtype = 'O+',
                dealerrep = 0,
                craftingrep = 0,
                attachmentcraftingrep = 0,
                currentapartment = nil,
                callsign = 'NO CALLSIGN',
                fingerprint = TA2Core.Shared.RandomStr(2) .. TA2Core.Shared.RandomInt(3) .. TA2Core.Shared.RandomStr(1) .. TA2Core.Shared.RandomInt(2) .. TA2Core.Shared.RandomStr(3) .. TA2Core.Shared.RandomInt(4),
                walletid = TA2Core.Shared.RandomInt(8),
                licences = {
                    driver = true,
                    business = false,
                    weapon = false
                },
                inside = {
                    house = nil,
                    apartment = {
                        apartmentType = nil,
                        apartmentId = nil
                    }
                },
                phonedata = {
                    SerialNumber = TA2Core.Shared.RandomInt(8),
                    InstalledApps = {}
                }
            }
            
            -- Save new player to database
            MySQL.insert('INSERT INTO players (citizenid, license, name, money, charinfo, job, gang, position, metadata) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', {
                PlayerData.citizenid,
                PlayerData.license,
                PlayerData.name,
                json.encode(PlayerData.money),
                json.encode(PlayerData.charinfo),
                json.encode(PlayerData.job),
                json.encode(PlayerData.gang),
                json.encode(PlayerData.position),
                json.encode(PlayerData.metadata)
            })
        end
    end
    
    -- Create player object
    local self = {}
    self.Functions = {}
    self.PlayerData = PlayerData
    self.Offline = false
    
    -- Money Functions
    self.Functions.AddMoney = function(moneytype, amount, reason)
        reason = reason or 'unknown'
        amount = tonumber(amount)
        if amount < 0 then return false end
        if not self.PlayerData.money[moneytype] then return false end
        
        self.PlayerData.money[moneytype] = self.PlayerData.money[moneytype] + amount
        self.Functions.UpdatePlayerData()
        TriggerClientEvent('TA2Core:Client:OnMoneyChange', source, moneytype, amount, false, reason)
        TriggerEvent('TA2Core:Server:OnMoneyChange', source, moneytype, amount, 'add', reason)
        
        return true
    end
    
    self.Functions.RemoveMoney = function(moneytype, amount, reason)
        reason = reason or 'unknown'
        amount = tonumber(amount)
        if amount < 0 then return false end
        if not self.PlayerData.money[moneytype] then return false end
        
        for _, mtype in pairs({'cash', 'bank'}) do
            if self.PlayerData.money[mtype] >= amount then
                self.PlayerData.money[mtype] = self.PlayerData.money[mtype] - amount
                self.Functions.UpdatePlayerData()
                TriggerClientEvent('TA2Core:Client:OnMoneyChange', source, mtype, amount, true, reason)
                TriggerEvent('TA2Core:Server:OnMoneyChange', source, mtype, amount, 'remove', reason)
                return true
            end
        end
        
        return false
    end
    
    self.Functions.SetMoney = function(moneytype, amount, reason)
        reason = reason or 'unknown'
        amount = tonumber(amount)
        if amount < 0 then return false end
        if not self.PlayerData.money[moneytype] then return false end
        
        self.PlayerData.money[moneytype] = amount
        self.Functions.UpdatePlayerData()
        TriggerClientEvent('TA2Core:Client:OnMoneyChange', source, moneytype, amount, false, reason)
        
        return true
    end
    
    self.Functions.GetMoney = function(moneytype)
        if not moneytype then return 0 end
        return self.PlayerData.money[moneytype] or 0
    end
    
    -- Job Functions
    self.Functions.SetJob = function(job, grade)
        grade = tostring(grade) or '0'
        if not TA2Core.Shared.Jobs[job] then return false end
        
        self.PlayerData.job.name = job
        self.PlayerData.job.label = TA2Core.Shared.Jobs[job].label
        self.PlayerData.job.onduty = TA2Core.Shared.Jobs[job].defaultDuty
        self.PlayerData.job.grade = {}
        self.PlayerData.job.grade.name = TA2Core.Shared.Jobs[job].grades[grade].name
        self.PlayerData.job.grade.level = tonumber(grade)
        self.PlayerData.job.payment = TA2Core.Shared.Jobs[job].grades[grade].payment or 30
        self.PlayerData.job.isboss = TA2Core.Shared.Jobs[job].grades[grade].isboss or false
        
        self.Functions.UpdatePlayerData()
        TriggerClientEvent('TA2Core:Client:OnJobUpdate', source, self.PlayerData.job)
        TriggerEvent('TA2Core:Server:OnJobUpdate', source, self.PlayerData.job)
        
        return true
    end
    
    self.Functions.SetJobDuty = function(onDuty)
        self.PlayerData.job.onduty = onDuty
        TriggerClientEvent('TA2Core:Client:SetDuty', source, onDuty)
    end
    
    -- Gang Functions
    self.Functions.SetGang = function(gang, grade)
        grade = tostring(grade) or '0'
        self.PlayerData.gang.name = gang
        self.PlayerData.gang.label = gang
        self.PlayerData.gang.isboss = false
        self.PlayerData.gang.grade = {}
        self.PlayerData.gang.grade.name = gang
        self.PlayerData.gang.grade.level = tonumber(grade)
        
        self.Functions.UpdatePlayerData()
        TriggerClientEvent('TA2Core:Client:OnGangUpdate', source, self.PlayerData.gang)
        
        return true
    end
    
    -- MetaData Functions
    self.Functions.SetMetaData = function(meta, value)
        if not meta or type(meta) ~= 'string' then return end
        self.PlayerData.metadata[meta] = value
        self.Functions.UpdatePlayerData()
    end
    
    self.Functions.GetMetaData = function(meta)
        if not meta or type(meta) ~= 'string' then return end
        return self.PlayerData.metadata[meta]
    end
    
    -- Position Functions
    self.Functions.SetPosition = function(position)
        self.PlayerData.position = position
    end
    
    self.Functions.GetPosition = function()
        return self.PlayerData.position
    end
    
    -- Update & Save Functions
    self.Functions.UpdatePlayerData = function()
        TriggerClientEvent('TA2Core:Player:SetPlayerData', source, self.PlayerData)
    end
    
    self.Functions.Save = function()
        MySQL.update('UPDATE players SET money = ?, charinfo = ?, job = ?, gang = ?, position = ?, metadata = ? WHERE citizenid = ?', {
            json.encode(self.PlayerData.money),
            json.encode(self.PlayerData.charinfo),
            json.encode(self.PlayerData.job),
            json.encode(self.PlayerData.gang),
            json.encode(self.PlayerData.position),
            json.encode(self.PlayerData.metadata),
            self.PlayerData.citizenid
        })
        
        TA2Core.Debug('ta2-core', 'Saved player: ' .. self.PlayerData.citizenid)
    end
    
    self.Functions.Logout = function()
        self.Functions.Save()
        TA2Core.Players[source] = nil
    end
    
    -- Store player
    TA2Core.Players[source] = self
    
    -- Send player data to client
    TriggerClientEvent('TA2Core:Client:OnPlayerLoaded', source)
    TriggerClientEvent('TA2Core:Player:SetPlayerData', source, self.PlayerData)
    TriggerEvent('TA2Core:Server:PlayerLoaded', self.PlayerData)
    
    self.Functions.UpdatePlayerData()
    
    print('^2[TA2-Core]^7 Player ' .. GetPlayerName(source) .. ' loaded!')
    
    return self
end

-- Event for loading player
RegisterNetEvent('TA2Core:Server:OnPlayerLoaded', function()
    local src = source
    -- Player loaded event
end)
