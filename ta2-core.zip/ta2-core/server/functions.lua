-- Utility Functions
TA2Core.Functions.GetIdentifier = function(source, idtype)
    local identifiers = GetPlayerIdentifiers(source)
    for _, identifier in pairs(identifiers) do
        if string.find(identifier, idtype) then
            return identifier
        end
    end
    return nil
end

TA2Core.Functions.GetSource = function(identifier)
    for k, v in pairs(TA2Core.Players) do
        local idens = GetPlayerIdentifiers(k)
        for _, id in pairs(idens) do
            if identifier == id then
                return k
            end
        end
    end
    return 0
end

TA2Core.Functions.GetPlayer = function(source)
    if type(source) == 'number' then
        return TA2Core.Players[source]
    else
        return TA2Core.Players[TA2Core.Functions.GetSource(source)]
    end
end

TA2Core.Functions.GetPlayerByCitizenId = function(citizenid)
    for _, v in pairs(TA2Core.Players) do
        if v.PlayerData.citizenid == citizenid then
            return v
        end
    end
    return nil
end

TA2Core.Functions.GetPlayers = function()
    local sources = {}
    for k in pairs(TA2Core.Players) do
        sources[#sources + 1] = k
    end
    return sources
end

TA2Core.Functions.CreateUseableItem = function(item, cb)
    TA2Core.UseableItems[item] = cb
end

TA2Core.Functions.CanUseItem = function(item)
    return TA2Core.UseableItems[item] ~= nil
end

TA2Core.Functions.UseItem = function(source, item)
    if TA2Core.Functions.CanUseItem(item) then
        TA2Core.UseableItems[item](source, item)
    end
end

TA2Core.Functions.Kick = function(source, reason, setKickReason, deferrals)
    reason = reason or 'You have been kicked from the server'
    setKickReason = setKickReason or reason
    
    if deferrals then
        deferrals.update(reason)
        Wait(2500)
    end
    
    DropPlayer(source, setKickReason)
end

TA2Core.Functions.IsWhitelisted = function(source)
    -- Placeholder for whitelist system
    return true
end

TA2Core.Functions.AddPermission = function(source, permission)
    local Player = TA2Core.Functions.GetPlayer(source)
    if not Player then return false end
    
    local permissions = Player.PlayerData.metadata.permissions or {}
    permissions[permission] = true
    Player.Functions.SetMetaData('permissions', permissions)
end

TA2Core.Functions.RemovePermission = function(source, permission)
    local Player = TA2Core.Functions.GetPlayer(source)
    if not Player then return false end
    
    local permissions = Player.PlayerData.metadata.permissions or {}
    permissions[permission] = nil
    Player.Functions.SetMetaData('permissions', permissions)
end

TA2Core.Functions.HasPermission = function(source, permission)
    local Player = TA2Core.Functions.GetPlayer(source)
    if not Player then return false end
    
    local permissions = Player.PlayerData.metadata.permissions or {}
    return permissions[permission] == true
end

TA2Core.Functions.GetPermissions = function(source)
    local Player = TA2Core.Functions.GetPlayer(source)
    if not Player then return {} end
    return Player.PlayerData.metadata.permissions or {}
end

TA2Core.Functions.IsOptin = function(source)
    local Player = TA2Core.Functions.GetPlayer(source)
    if not Player then return false end
    return Player.PlayerData.metadata.optin or false
end

TA2Core.Functions.ToggleOptin = function(source)
    local Player = TA2Core.Functions.GetPlayer(source)
    if not Player then return end
    Player.Functions.SetMetaData('optin', not Player.PlayerData.metadata.optin)
end

TA2Core.Functions.IsPlayerBusy = function(source)
    local Player = TA2Core.Functions.GetPlayer(source)
    if not Player then return false end
    return Player.PlayerData.metadata.isbusy or false
end

TA2Core.Functions.SetPlayerBusy = function(source, busy)
    local Player = TA2Core.Functions.GetPlayer(source)
    if not Player then return end
    Player.Functions.SetMetaData('isbusy', busy)
end

-- Notification
TA2Core.Functions.Notify = function(source, text, type, length)
    TriggerClientEvent('TA2Core:Notify', source, text, type, length)
end

-- Generate Random Citizen ID
TA2Core.Functions.CreateCitizenId = function()
    local UniqueFound = false
    local CitizenId = nil
    
    while not UniqueFound do
        CitizenId = TA2Core.Shared.RandomStr(3) .. TA2Core.Shared.RandomInt(5)
        local result = MySQL.query.await('SELECT COUNT(*) as count FROM players WHERE citizenid = ?', {CitizenId})
        if result[1].count == 0 then
            UniqueFound = true
        end
    end
    
    return CitizenId
end

-- Item Helpers
TA2Core.Functions.GetItemLabel = function(item)
    if TA2Core.Shared.Items[item] then
        return TA2Core.Shared.Items[item].label
    end
    return 'Unknown Item'
end
