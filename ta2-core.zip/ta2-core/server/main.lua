-- TA2Core Server Object
TA2Core = TA2Core or {}
TA2Core.Players = {}
TA2Core.Functions = {}
TA2Core.UseableItems = {}

-- Initialize Core
CreateThread(function()
    print('^2[TA2-Core]^7 Starting TA2-Core Framework...')
    
    -- Wait for database to be ready
    MySQL.ready(function()
        print('^2[TA2-Core]^7 Database connection established')
        
        -- Create tables if they don't exist
        MySQL.query([[
            CREATE TABLE IF NOT EXISTS `players` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `citizenid` varchar(50) NOT NULL,
                `license` varchar(255) NOT NULL,
                `name` varchar(255) NOT NULL,
                `money` text DEFAULT NULL,
                `charinfo` text DEFAULT NULL,
                `job` text DEFAULT NULL,
                `gang` text DEFAULT NULL,
                `position` text DEFAULT NULL,
                `metadata` text DEFAULT NULL,
                `inventory` longtext DEFAULT NULL,
                `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
                PRIMARY KEY (`citizenid`),
                KEY `id` (`id`),
                KEY `last_updated` (`last_updated`),
                KEY `license` (`license`)
            ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
        ]])
        
        print('^2[TA2-Core]^7 Framework initialized successfully!')
    end)
end)

-- Player Connected
RegisterNetEvent('playerConnecting', function()
    local src = source
    local license = TA2Core.Functions.GetIdentifier(src, 'license')
    
    if not license then
        DropPlayer(src, 'No valid Rockstar license found')
        return
    end
end)

-- Player Loaded
AddEventHandler('playerJoining', function()
    local src = source
    TA2Core.Functions.CreatePlayer(src)
end)

-- Player Disconnected
AddEventHandler('playerDropped', function()
    local src = source
    local Player = TA2Core.Functions.GetPlayer(src)
    
    if Player then
        Player.Functions.Save()
        TA2Core.Players[src] = nil
        print('^3[TA2-Core]^7 Player ' .. GetPlayerName(src) .. ' disconnected')
    end
end)

-- Resource Stop - Save all players
AddEventHandler('onResourceStop', function(resourceName)
    if GetCurrentResourceName() ~= resourceName then return end
    
    for k, v in pairs(TA2Core.Players) do
        v.Functions.Save()
    end
end)

-- Get Core Object (for other resources)
function GetCoreObject()
    return TA2Core
end

-- Export
exports('GetCoreObject', GetCoreObject)
