-- Commands System
TA2Core.Commands = {}
TA2Core.Commands.List = {}

-- Add Command
TA2Core.Commands.Add = function(name, help, arguments, argsrequired, callback, permission)
    TA2Core.Commands.List[name] = {
        name = name,
        help = help,
        arguments = arguments,
        argsrequired = argsrequired,
        callback = callback,
        permission = permission
    }
end

-- Refresh Commands (register with server)
TA2Core.Commands.Refresh = function(source)
    local Player = TA2Core.Functions.GetPlayer(source)
    if not Player then return end
    
    for command, info in pairs(TA2Core.Commands.List) do
        if not info.permission or TA2Core.Functions.HasPermission(source, info.permission) then
            TriggerClientEvent('chat:addSuggestion', source, '/' .. command, info.help, info.arguments)
        end
    end
end

-- Register command with FiveM
local function RegisterCommand(name, permission, callback, suggestion)
    RegisterCommand(name, function(source, args, rawCommand)
        local src = source
        
        if permission and not TA2Core.Functions.HasPermission(src, permission) then
            TriggerClientEvent('chatMessage', src, 'SYSTEM', 'error', 'You don\'t have permission to use this command')
            return
        end
        
        callback(src, args, rawCommand)
    end, false)
    
    if suggestion then
        TriggerClientEvent('chat:addSuggestion', -1, '/' .. name, suggestion.help, suggestion.arguments)
    end
end

-- Admin Commands
TA2Core.Commands.Add('givemoney', 'Give money to a player', {
    {name = 'id', help = 'Player ID'},
    {name = 'moneytype', help = 'Type of money (cash/bank)'},
    {name = 'amount', help = 'Amount'}
}, true, function(source, args)
    local target = tonumber(args[1])
    local moneytype = args[2]:lower()
    local amount = tonumber(args[3])
    
    if not target or not amount then
        TriggerClientEvent('chatMessage', source, 'SYSTEM', 'error', 'Invalid arguments')
        return
    end
    
    local Player = TA2Core.Functions.GetPlayer(target)
    if not Player then
        TriggerClientEvent('chatMessage', source, 'SYSTEM', 'error', 'Player not found')
        return
    end
    
    if moneytype ~= 'cash' and moneytype ~= 'bank' then
        TriggerClientEvent('chatMessage', source, 'SYSTEM', 'error', 'Invalid money type')
        return
    end
    
    Player.Functions.AddMoney(moneytype, amount, 'Admin give money')
    TriggerClientEvent('chatMessage', source, 'SYSTEM', 'success', 'Gave $' .. amount .. ' ' .. moneytype .. ' to player ' .. target)
end, 'admin')

RegisterCommand('givemoney', 'admin', function(source, args, rawCommand)
    if TA2Core.Commands.List['givemoney'] then
        TA2Core.Commands.List['givemoney'].callback(source, args)
    end
end, {
    help = 'Give money to a player',
    arguments = {
        {name = 'id', help = 'Player ID'},
        {name = 'moneytype', help = 'Type of money (cash/bank)'},
        {name = 'amount', help = 'Amount'}
    }
})

-- Set Job Command
TA2Core.Commands.Add('setjob', 'Set a player\'s job', {
    {name = 'id', help = 'Player ID'},
    {name = 'job', help = 'Job name'},
    {name = 'grade', help = 'Job grade'}
}, true, function(source, args)
    local target = tonumber(args[1])
    local job = args[2]:lower()
    local grade = tonumber(args[3]) or 0
    
    if not target then
        TriggerClientEvent('chatMessage', source, 'SYSTEM', 'error', 'Invalid player ID')
        return
    end
    
    local Player = TA2Core.Functions.GetPlayer(target)
    if not Player then
        TriggerClientEvent('chatMessage', source, 'SYSTEM', 'error', 'Player not found')
        return
    end
    
    if not TA2Core.Shared.Jobs[job] then
        TriggerClientEvent('chatMessage', source, 'SYSTEM', 'error', 'Invalid job name')
        return
    end
    
    Player.Functions.SetJob(job, grade)
    TriggerClientEvent('chatMessage', source, 'SYSTEM', 'success', 'Set player ' .. target .. ' job to ' .. job .. ' grade ' .. grade)
end, 'admin')

RegisterCommand('setjob', 'admin', function(source, args, rawCommand)
    if TA2Core.Commands.List['setjob'] then
        TA2Core.Commands.List['setjob'].callback(source, args)
    end
end, {
    help = 'Set a player\'s job',
    arguments = {
        {name = 'id', help = 'Player ID'},
        {name = 'job', help = 'Job name'},
        {name = 'grade', help = 'Job grade'}
    }
})

-- Car Command
TA2Core.Commands.Add('car', 'Spawn a vehicle', {
    {name = 'model', help = 'Vehicle model name'}
}, true, function(source, args)
    local model = args[1]
    
    if not model then
        TriggerClientEvent('chatMessage', source, 'SYSTEM', 'error', 'Invalid vehicle model')
        return
    end
    
    TriggerClientEvent('TA2Core:Command:SpawnVehicle', source, model)
end, 'admin')

RegisterCommand('car', 'admin', function(source, args, rawCommand)
    if TA2Core.Commands.List['car'] then
        TA2Core.Commands.List['car'].callback(source, args)
    end
end, {
    help = 'Spawn a vehicle',
    arguments = {
        {name = 'model', help = 'Vehicle model name'}
    }
})

-- Delete Vehicle Command
TA2Core.Commands.Add('dv', 'Delete vehicle', {}, false, function(source, args)
    TriggerClientEvent('TA2Core:Command:DeleteVehicle', source)
end)

RegisterCommand('dv', false, function(source, args, rawCommand)
    if TA2Core.Commands.List['dv'] then
        TA2Core.Commands.List['dv'].callback(source, args)
    end
end, {
    help = 'Delete nearby vehicle',
    arguments = {}
})

-- Coords Command
TA2Core.Commands.Add('coords', 'Show current coordinates', {}, false, function(source, args)
    TriggerClientEvent('TA2Core:Command:ShowCoords', source)
end)

RegisterCommand('coords', false, function(source, args, rawCommand)
    if TA2Core.Commands.List['coords'] then
        TA2Core.Commands.List['coords'].callback(source, args)
    end
end, {
    help = 'Show current coordinates',
    arguments = {}
})

print('^2[TA2-Core]^7 Commands loaded')
