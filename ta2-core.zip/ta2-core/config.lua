Config = {}

-- Server Settings
Config.MaxPlayers = GetConvarInt('sv_maxclients', 48)
Config.DefaultSpawn = vector4(-1035.71, -2731.87, 12.76, 0.0)
Config.UpdateInterval = 5 -- minutes
Config.StatusInterval = 5000 -- milliseconds

-- Player Settings
Config.StartingCash = 5000
Config.StartingBank = 25000
Config.DefaultJob = 'unemployed'
Config.DefaultGrade = 0
Config.EnablePVP = true

-- Inventory Settings
Config.MaxWeight = 120000 -- grams
Config.MaxSlots = 41

-- Vehicle Settings
Config.EnableVehicleKeys = true
Config.EnableFuelSystem = true

-- Money Settings
Config.MoneyForm = 'DOLLARS' -- Formatting
Config.MoneySymbol = '$'

-- Database Table Names (customize if needed)
Config.Tables = {
    Players = 'players',
    Vehicles = 'player_vehicles',
    Houses = 'player_houses'
}

-- Debug Mode
Config.Debug = false
