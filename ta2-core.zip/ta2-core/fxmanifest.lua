fx_version 'cerulean'
game 'gta5'

author 'TA2-Development'
description 'TA2-Core - A FiveM Server Framework'
version '1.0.0'

shared_scripts {
    'config.lua',
    'shared/main.lua',
    'shared/jobs.lua',
    'shared/items.lua',
    'shared/vehicles.lua',
    'shared/weapons.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/main.lua',
    'server/functions.lua',
    'server/player.lua',
    'server/callbacks.lua',
    'server/commands.lua'
}

client_scripts {
    'client/main.lua',
    'client/functions.lua',
    'client/events.lua'
}

dependencies {
    'oxmysql'
}

lua54 'yes'
