TA2Core = {}
TA2Core.Shared = {}
TA2Core.Shared.Jobs = {}
TA2Core.Shared.Items = {}
TA2Core.Shared.Vehicles = {}
TA2Core.Shared.Weapons = {}

-- Utility Functions
function TA2Core.Shared.Round(value, numDecimalPlaces)
    if not numDecimalPlaces then return math.floor(value + 0.5) end
    local power = 10 ^ numDecimalPlaces
    return math.floor((value * power) + 0.5) / power
end

function TA2Core.Shared.Trim(value)
    if not value then return nil end
    return (string.gsub(value, '^%s*(.-)%s*$', '%1'))
end

function TA2Core.Shared.SplitStr(str, delimiter)
    local result = {}
    local from = 1
    local delim_from, delim_to = string.find(str, delimiter, from)
    while delim_from do
        table.insert(result, string.sub(str, from, delim_from - 1))
        from = delim_to + 1
        delim_from, delim_to = string.find(str, delimiter, from)
    end
    table.insert(result, string.sub(str, from))
    return result
end

function TA2Core.Shared.RandomStr(length)
    if length <= 0 then return '' end
    local str = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
    return TA2Core.Shared.RandomStr(length - 1) .. str:sub(math.random(1, #str), 1)
end

function TA2Core.Shared.RandomInt(length)
    if length <= 0 then return '' end
    local str = '0123456789'
    return TA2Core.Shared.RandomInt(length - 1) .. str:sub(math.random(1, #str), 1)
end

function TA2Core.Shared.StartsWithLetter(str)
    return string.match(str, '^[a-zA-Z]') ~= nil
end

function TA2Core.Shared.GetVehicleByPlate(plate)
    for k, v in pairs(TA2Core.Shared.Vehicles) do
        if v.plate == plate then
            return v
        end
    end
    return nil
end

function TA2Core.Debug(resource, msg)
    if Config.Debug then
        print('^3[DEBUG - ' .. resource .. ']^7 ' .. msg .. '^7')
    end
end
