TA2Core.Shared.Items = {
    -- Weapons
    ['weapon_pistol'] = {
        name = 'weapon_pistol',
        label = 'Pistol',
        weight = 1000,
        type = 'weapon',
        ammotype = 'AMMO_PISTOL',
        image = 'weapon_pistol.png',
        unique = true,
        useable = false,
        description = 'A small firearm'
    },
    
    -- Consumables
    ['water_bottle'] = {
        name = 'water_bottle',
        label = 'Water Bottle',
        weight = 500,
        type = 'item',
        image = 'water_bottle.png',
        unique = false,
        useable = true,
        shouldClose = true,
        description = 'Refreshing bottled water'
    },
    ['sandwich'] = {
        name = 'sandwich',
        label = 'Sandwich',
        weight = 200,
        type = 'item',
        image = 'sandwich.png',
        unique = false,
        useable = true,
        shouldClose = true,
        description = 'A delicious sandwich'
    },
    ['coffee'] = {
        name = 'coffee',
        label = 'Coffee',
        weight = 300,
        type = 'item',
        image = 'coffee.png',
        unique = false,
        useable = true,
        shouldClose = true,
        description = 'Hot coffee to wake you up'
    },
    
    -- Tools
    ['lockpick'] = {
        name = 'lockpick',
        label = 'Lockpick',
        weight = 100,
        type = 'item',
        image = 'lockpick.png',
        unique = false,
        useable = true,
        shouldClose = true,
        description = 'Tool for picking locks'
    },
    ['phone'] = {
        name = 'phone',
        label = 'Phone',
        weight = 200,
        type = 'item',
        image = 'phone.png',
        unique = true,
        useable = true,
        shouldClose = false,
        description = 'Smartphone for communication'
    },
    ['id_card'] = {
        name = 'id_card',
        label = 'ID Card',
        weight = 0,
        type = 'item',
        image = 'id_card.png',
        unique = true,
        useable = true,
        shouldClose = false,
        description = 'Identification card'
    },
    ['driver_license'] = {
        name = 'driver_license',
        label = 'Driver License',
        weight = 0,
        type = 'item',
        image = 'driver_license.png',
        unique = true,
        useable = true,
        shouldClose = false,
        description = 'Legal driving permit'
    },
    
    -- Currency & Valuables
    ['money'] = {
        name = 'money',
        label = 'Cash',
        weight = 0,
        type = 'item',
        image = 'money.png',
        unique = false,
        useable = false,
        shouldClose = false,
        description = 'Dollar bills'
    },
    ['black_money'] = {
        name = 'black_money',
        label = 'Marked Bills',
        weight = 0,
        type = 'item',
        image = 'black_money.png',
        unique = false,
        useable = false,
        shouldClose = false,
        description = 'Untraceable cash'
    },
    
    -- Misc
    ['radio'] = {
        name = 'radio',
        label = 'Radio',
        weight = 500,
        type = 'item',
        image = 'radio.png',
        unique = true,
        useable = true,
        shouldClose = true,
        description = 'Communication radio'
    },
    ['handcuffs'] = {
        name = 'handcuffs',
        label = 'Handcuffs',
        weight = 100,
        type = 'item',
        image = 'handcuffs.png',
        unique = false,
        useable = true,
        shouldClose = true,
        description = 'Police restraints'
    }
}
