TA2Core.Shared.Vehicles = {
    -- Compacts
    ['blista'] = {
        name = 'Blista',
        brand = 'Dinka',
        model = 'blista',
        price = 15000,
        category = 'compacts',
        hash = `blista`,
        shop = 'pdm'
    },
    
    -- Sedans
    ['asea'] = {
        name = 'Asea',
        brand = 'Declasse',
        model = 'asea',
        price = 12000,
        category = 'sedans',
        hash = `asea`,
        shop = 'pdm'
    },
    ['premier'] = {
        name = 'Premier',
        brand = 'Declasse',
        model = 'premier',
        price = 18000,
        category = 'sedans',
        hash = `premier`,
        shop = 'pdm'
    },
    
    -- SUVs
    ['baller'] = {
        name = 'Baller',
        brand = 'Gallivanter',
        model = 'baller',
        price = 50000,
        category = 'suvs',
        hash = `baller`,
        shop = 'pdm'
    },
    ['seminole'] = {
        name = 'Seminole',
        brand = 'Canis',
        model = 'seminole',
        price = 35000,
        category = 'suvs',
        hash = `seminole`,
        shop = 'pdm'
    },
    
    -- Sports
    ['comet2'] = {
        name = 'Comet',
        brand = 'Pfister',
        model = 'comet2',
        price = 100000,
        category = 'sports',
        hash = `comet2`,
        shop = 'luxury'
    },
    ['furoregt'] = {
        name = 'Furore GT',
        brand = 'Lampadati',
        model = 'furoregt',
        price = 125000,
        category = 'sports',
        hash = `furoregt`,
        shop = 'luxury'
    },
    
    -- Motorcycles
    ['bati'] = {
        name = 'Bati 801',
        brand = 'Pegassi',
        model = 'bati',
        price = 15000,
        category = 'motorcycles',
        hash = `bati`,
        shop = 'pdm'
    },
    
    -- Vans
    ['burrito'] = {
        name = 'Burrito',
        brand = 'Declasse',
        model = 'burrito',
        price = 20000,
        category = 'vans',
        hash = `burrito`,
        shop = 'pdm'
    },
    
    -- Emergency (not for sale)
    ['police'] = {
        name = 'Police Cruiser',
        brand = 'Vapid',
        model = 'police',
        price = 0,
        category = 'emergency',
        hash = `police`,
        shop = 'none'
    },
    ['ambulance'] = {
        name = 'Ambulance',
        brand = 'Brute',
        model = 'ambulance',
        price = 0,
        category = 'emergency',
        hash = `ambulance`,
        shop = 'none'
    }
}
