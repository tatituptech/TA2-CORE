TA2Core.Shared.Weapons = {
    -- Melee
    ['weapon_dagger'] = {
        name = 'weapon_dagger',
        label = 'Dagger',
        weight = 500,
        ammotype = nil,
        damageType = 'melee'
    },
    ['weapon_bat'] = {
        name = 'weapon_bat',
        label = 'Baseball Bat',
        weight = 1000,
        ammotype = nil,
        damageType = 'melee'
    },
    ['weapon_knife'] = {
        name = 'weapon_knife',
        label = 'Knife',
        weight = 300,
        ammotype = nil,
        damageType = 'melee'
    },
    
    -- Handguns
    ['weapon_pistol'] = {
        name = 'weapon_pistol',
        label = 'Pistol',
        weight = 1000,
        ammotype = 'AMMO_PISTOL',
        damageType = 'firearm'
    },
    ['weapon_combatpistol'] = {
        name = 'weapon_combatpistol',
        label = 'Combat Pistol',
        weight = 1000,
        ammotype = 'AMMO_PISTOL',
        damageType = 'firearm'
    },
    ['weapon_heavypistol'] = {
        name = 'weapon_heavypistol',
        label = 'Heavy Pistol',
        weight = 1200,
        ammotype = 'AMMO_PISTOL',
        damageType = 'firearm'
    },
    ['weapon_snspistol'] = {
        name = 'weapon_snspistol',
        label = 'SNS Pistol',
        weight = 800,
        ammotype = 'AMMO_PISTOL',
        damageType = 'firearm'
    },
    
    -- SMGs
    ['weapon_microsmg'] = {
        name = 'weapon_microsmg',
        label = 'Micro SMG',
        weight = 2500,
        ammotype = 'AMMO_SMG',
        damageType = 'firearm'
    },
    ['weapon_smg'] = {
        name = 'weapon_smg',
        label = 'SMG',
        weight = 3000,
        ammotype = 'AMMO_SMG',
        damageType = 'firearm'
    },
    
    -- Shotguns
    ['weapon_pumpshotgun'] = {
        name = 'weapon_pumpshotgun',
        label = 'Pump Shotgun',
        weight = 4000,
        ammotype = 'AMMO_SHOTGUN',
        damageType = 'firearm'
    },
    ['weapon_sawnoffshotgun'] = {
        name = 'weapon_sawnoffshotgun',
        label = 'Sawed-Off Shotgun',
        weight = 3000,
        ammotype = 'AMMO_SHOTGUN',
        damageType = 'firearm'
    },
    
    -- Assault Rifles
    ['weapon_assaultrifle'] = {
        name = 'weapon_assaultrifle',
        label = 'Assault Rifle',
        weight = 4500,
        ammotype = 'AMMO_RIFLE',
        damageType = 'firearm'
    },
    ['weapon_carbinerifle'] = {
        name = 'weapon_carbinerifle',
        label = 'Carbine Rifle',
        weight = 4000,
        ammotype = 'AMMO_RIFLE',
        damageType = 'firearm'
    },
    
    -- Sniper Rifles
    ['weapon_sniperrifle'] = {
        name = 'weapon_sniperrifle',
        label = 'Sniper Rifle',
        weight = 6000,
        ammotype = 'AMMO_SNIPER',
        damageType = 'firearm'
    },
    
    -- Throwables
    ['weapon_grenade'] = {
        name = 'weapon_grenade',
        label = 'Grenade',
        weight = 500,
        ammotype = nil,
        damageType = 'explosive',
        throwable = true
    },
    ['weapon_molotov'] = {
        name = 'weapon_molotov',
        label = 'Molotov Cocktail',
        weight = 500,
        ammotype = nil,
        damageType = 'fire',
        throwable = true
    },
    
    -- Ammo Types
    ['pistol_ammo'] = {
        name = 'pistol_ammo',
        label = 'Pistol Ammo',
        weight = 50,
        ammotype = 'AMMO_PISTOL'
    },
    ['smg_ammo'] = {
        name = 'smg_ammo',
        label = 'SMG Ammo',
        weight = 75,
        ammotype = 'AMMO_SMG'
    },
    ['shotgun_ammo'] = {
        name = 'shotgun_ammo',
        label = 'Shotgun Ammo',
        weight = 100,
        ammotype = 'AMMO_SHOTGUN'
    },
    ['rifle_ammo'] = {
        name = 'rifle_ammo',
        label = 'Rifle Ammo',
        weight = 100,
        ammotype = 'AMMO_RIFLE'
    },
    ['sniper_ammo'] = {
        name = 'sniper_ammo',
        label = 'Sniper Ammo',
        weight = 150,
        ammotype = 'AMMO_SNIPER'
    }
}
