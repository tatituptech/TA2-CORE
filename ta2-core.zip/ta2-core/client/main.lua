-- TA2Core Client Object
TA2Core = TA2Core or {}
TA2Core.PlayerData = {}
TA2Core.Functions = {}
TA2Core.ServerCallbacks = {}
local isLoggedIn = false

-- Player Loaded
RegisterNetEvent('TA2Core:Client:OnPlayerLoaded', function()
    ShutdownLoadingScreenNui()
    isLoggedIn = true
    print('^2[TA2-Core]^7 Player loaded on client side')
end)

-- Player Unloaded
RegisterNetEvent('TA2Core:Client:OnPlayerUnload', function()
    isLoggedIn = false
end)

-- Set Player Data
RegisterNetEvent('TA2Core:Player:SetPlayerData', function(PlayerData)
    TA2Core.PlayerData = PlayerData
end)

-- Money Change
RegisterNetEvent('TA2Core:Client:OnMoneyChange', function(moneytype, amount, remove, reason)
    -- Handle money change notifications/UI updates
    TA2Core.Debug('ta2-core', 'Money changed: ' .. moneytype .. ' ' .. (remove and '-' or '+') .. amount)
end)

-- Job Update
RegisterNetEvent('TA2Core:Client:OnJobUpdate', function(JobInfo)
    TA2Core.PlayerData.job = JobInfo
    TA2Core.Functions.Notify('Job updated: ' .. JobInfo.label, 'success')
end)

-- Gang Update
RegisterNetEvent('TA2Core:Client:OnGangUpdate', function(GangInfo)
    TA2Core.PlayerData.gang = GangInfo
end)

-- Set Duty
RegisterNetEvent('TA2Core:Client:SetDuty', function(onDuty)
    TA2Core.PlayerData.job.onduty = onDuty
end)

-- Get Core Object
function GetCoreObject()
    return TA2Core
end

exports('GetCoreObject', GetCoreObject)

-- Check if logged in
CreateThread(function()
    while true do
        Wait(1000)
        if LocalPlayer.state.isLoggedIn then
            if not isLoggedIn then
                TriggerServerEvent('TA2Core:Server:OnPlayerLoaded')
                isLoggedIn = true
            end
        end
    end
end)

print('^2[TA2-Core]^7 Client initialized')
