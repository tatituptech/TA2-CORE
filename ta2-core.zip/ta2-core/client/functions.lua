-- Client Functions
TA2Core.Functions.GetPlayerData = function(cb)
    if not cb then return TA2Core.PlayerData end
    cb(TA2Core.PlayerData)
end

TA2Core.Functions.GetCoords = function(entity)
    local coords = GetEntityCoords(entity or PlayerPedId())
    return vector4(coords.x, coords.y, coords.z, GetEntityHeading(entity or PlayerPedId()))
end

TA2Core.Functions.HasItem = function(itemname)
    -- Placeholder - would integrate with inventory system
    return false
end

TA2Core.Functions.Notify = function(text, texttype, length)
    if type(text) == 'table' then
        local ttext = text.text or 'Placeholder'
        local caption = text.caption or 'Notification'
        texttype = texttype or 'primary'
        length = length or 5000
        
        -- Send to chat as fallback
        TriggerEvent('chat:addMessage', {
            color = texttype == 'error' and {255, 0, 0} or texttype == 'success' and {0, 255, 0} or {255, 255, 255},
            multiline = false,
            args = {caption, ttext}
        })
    else
        local ttext = text or 'Placeholder'
        texttype = texttype or 'primary'
        length = length or 5000
        
        -- Send to chat as fallback
        TriggerEvent('chat:addMessage', {
            color = texttype == 'error' and {255, 0, 0} or texttype == 'success' and {0, 255, 0} or {255, 255, 255},
            multiline = false,
            args = {'SYSTEM', ttext}
        })
    end
end

RegisterNetEvent('TA2Core:Notify', function(text, texttype, length)
    TA2Core.Functions.Notify(text, texttype, length)
end)

-- Progress Bar
TA2Core.Functions.Progressbar = function(name, label, duration, useWhileDead, canCancel, disableControls, animation, prop, propTwo, onFinish, onCancel)
    -- Placeholder for progress bar system
    -- This would integrate with a progress bar resource
    if onFinish then
        SetTimeout(duration, function()
            onFinish()
        end)
    end
end

-- Draw Text 3D
TA2Core.Functions.DrawText3D = function(x, y, z, text)
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry('STRING')
    SetTextCentre(true)
    AddTextComponentString(text)
    SetDrawOrigin(x, y, z, 0)
    DrawText(0.0, 0.0)
    local factor = (string.len(text)) / 370
    DrawRect(0.0, 0.0 + 0.0125, 0.017 + factor, 0.03, 0, 0, 0, 75)
    ClearDrawOrigin()
end

-- Spawn Vehicle
TA2Core.Functions.SpawnVehicle = function(model, cb, coords, isnetworked)
    local ped = PlayerPedId()
    local modelHash = type(model) == 'string' and GetHashKey(model) or model
    local coords = coords or GetEntityCoords(ped)
    isnetworked = isnetworked == nil and true or isnetworked
    
    RequestModel(modelHash)
    while not HasModelLoaded(modelHash) do
        Wait(10)
    end
    
    local vehicle = CreateVehicle(modelHash, coords.x, coords.y, coords.z, coords.w or GetEntityHeading(ped), isnetworked, false)
    SetVehicleHasBeenOwnedByPlayer(vehicle, true)
    SetEntityAsMissionEntity(vehicle, true, true)
    SetVehicleNeedsToBeHotwired(vehicle, false)
    SetModelAsNoLongerNeeded(modelHash)
    SetVehRadioStation(vehicle, 'OFF')
    
    if cb then
        cb(vehicle)
    end
    
    return vehicle
end

-- Delete Vehicle
TA2Core.Functions.DeleteVehicle = function(vehicle)
    SetEntityAsMissionEntity(vehicle, true, true)
    DeleteVehicle(vehicle)
end

-- Get Closest Player
TA2Core.Functions.GetClosestPlayer = function(coords)
    local ped = PlayerPedId()
    coords = coords or GetEntityCoords(ped)
    local closestPlayers = {}
    local players = GetActivePlayers()
    
    for _, player in ipairs(players) do
        local target = GetPlayerPed(player)
        if target ~= ped then
            local targetCoords = GetEntityCoords(target)
            local distance = #(coords - targetCoords)
            closestPlayers[#closestPlayers + 1] = {
                id = player,
                coords = targetCoords,
                ped = target,
                distance = distance
            }
        end
    end
    
    table.sort(closestPlayers, function(a, b)
        return a.distance < b.distance
    end)
    
    return closestPlayers[1]
end

-- Get Players in Area
TA2Core.Functions.GetPlayersInArea = function(coords, area)
    local players = {}
    local ped = PlayerPedId()
    local activePlayers = GetActivePlayers()
    
    for _, player in ipairs(activePlayers) do
        local target = GetPlayerPed(player)
        if target ~= ped then
            local targetCoords = GetEntityCoords(target)
            local distance = #(coords - targetCoords)
            if distance <= area then
                players[#players + 1] = player
            end
        end
    end
    
    return players
end

-- Get Closest Vehicle
TA2Core.Functions.GetClosestVehicle = function(coords)
    local ped = PlayerPedId()
    local vehicles = GetGamePool('CVehicle')
    local closestDistance = -1
    local closestVehicle = -1
    coords = coords or GetEntityCoords(ped)
    
    for _, v in ipairs(vehicles) do
        local vehicleCoords = GetEntityCoords(v)
        local distance = #(coords - vehicleCoords)
        
        if closestDistance == -1 or closestDistance > distance then
            closestVehicle = v
            closestDistance = distance
        end
    end
    
    return closestVehicle, closestDistance
end

-- Get Vehicle Properties
TA2Core.Functions.GetVehicleProperties = function(vehicle)
    if not DoesEntityExist(vehicle) then return end
    
    local colorPrimary, colorSecondary = GetVehicleColours(vehicle)
    local pearlescentColor, wheelColor = GetVehicleExtraColours(vehicle)
    
    return {
        model = GetEntityModel(vehicle),
        plate = GetVehicleNumberPlateText(vehicle),
        plateIndex = GetVehicleNumberPlateTextIndex(vehicle),
        bodyHealth = GetVehicleBodyHealth(vehicle),
        engineHealth = GetVehicleEngineHealth(vehicle),
        tankHealth = GetVehiclePetrolTankHealth(vehicle),
        fuelLevel = GetVehicleFuelLevel(vehicle),
        dirtLevel = GetVehicleDirtLevel(vehicle),
        color1 = colorPrimary,
        color2 = colorSecondary,
        pearlescentColor = pearlescentColor,
        wheelColor = wheelColor,
        wheels = GetVehicleWheelType(vehicle),
        windowTint = GetVehicleWindowTint(vehicle),
        xenonColor = GetVehicleXenonLightsColor(vehicle),
        neonEnabled = {
            IsVehicleNeonLightEnabled(vehicle, 0),
            IsVehicleNeonLightEnabled(vehicle, 1),
            IsVehicleNeonLightEnabled(vehicle, 2),
            IsVehicleNeonLightEnabled(vehicle, 3)
        },
        extras = {},
        tyreSmokeColor = table.pack(GetVehicleTyreSmokeColor(vehicle))
    }
end

-- Set Vehicle Properties
TA2Core.Functions.SetVehicleProperties = function(vehicle, props)
    if not DoesEntityExist(vehicle) then return end
    
    if props.plate then SetVehicleNumberPlateText(vehicle, props.plate) end
    if props.plateIndex then SetVehicleNumberPlateTextIndex(vehicle, props.plateIndex) end
    if props.bodyHealth then SetVehicleBodyHealth(vehicle, props.bodyHealth + 0.0) end
    if props.engineHealth then SetVehicleEngineHealth(vehicle, props.engineHealth + 0.0) end
    if props.tankHealth then SetVehiclePetrolTankHealth(vehicle, props.tankHealth + 0.0) end
    if props.fuelLevel then SetVehicleFuelLevel(vehicle, props.fuelLevel + 0.0) end
    if props.dirtLevel then SetVehicleDirtLevel(vehicle, props.dirtLevel + 0.0) end
    if props.color1 then SetVehicleColours(vehicle, props.color1, props.color2 or 0) end
    if props.pearlescentColor then SetVehicleExtraColours(vehicle, props.pearlescentColor, props.wheelColor or 0) end
    if props.wheels then SetVehicleWheelType(vehicle, props.wheels) end
    if props.windowTint then SetVehicleWindowTint(vehicle, props.windowTint) end
    
    if props.neonEnabled then
        for i = 1, #props.neonEnabled do
            SetVehicleNeonLightEnabled(vehicle, i - 1, props.neonEnabled[i])
        end
    end
end
