-- Client Callbacks
TA2Core.Functions.TriggerCallback = function(name, cb, ...)
    TA2Core.ServerCallbacks[name] = cb
    TriggerServerEvent('TA2Core:Server:TriggerCallback', name, ...)
end

RegisterNetEvent('TA2Core:Client:TriggerCallback', function(name, ...)
    if TA2Core.ServerCallbacks[name] then
        TA2Core.ServerCallbacks[name](...)
        TA2Core.ServerCallbacks[name] = nil
    end
end)

-- Command Events
RegisterNetEvent('TA2Core:Command:SpawnVehicle', function(model)
    TA2Core.Functions.SpawnVehicle(model, function(vehicle)
        TaskWarpPedIntoVehicle(PlayerPedId(), vehicle, -1)
        TA2Core.Functions.Notify('Vehicle spawned!', 'success')
    end)
end)

RegisterNetEvent('TA2Core:Command:DeleteVehicle', function()
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)
    
    if vehicle == 0 then
        local closestVeh, distance = TA2Core.Functions.GetClosestVehicle()
        if distance <= 5.0 then
            vehicle = closestVeh
        end
    end
    
    if vehicle ~= 0 then
        TA2Core.Functions.DeleteVehicle(vehicle)
        TA2Core.Functions.Notify('Vehicle deleted!', 'success')
    else
        TA2Core.Functions.Notify('No vehicle nearby!', 'error')
    end
end)

RegisterNetEvent('TA2Core:Command:ShowCoords', function()
    local coords = TA2Core.Functions.GetCoords()
    local coordsString = string.format('vector4(%.2f, %.2f, %.2f, %.2f)', coords.x, coords.y, coords.z, coords.w)
    
    TA2Core.Functions.Notify(coordsString, 'success', 10000)
    print('^2[Coords]^7 ' .. coordsString)
end)

-- Player Spawning
AddEventHandler('playerSpawned', function()
    SetPedDefaultComponentVariation(PlayerPedId())
    
    -- Set player as logged in
    LocalPlayer.state:set('isLoggedIn', true, false)
end)
